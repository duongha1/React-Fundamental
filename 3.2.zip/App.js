import "./App.css";

function App() {
	return (
		<div className="App">
			<h1>Welcome to my site</h1>
			<p>This is my first React app</p>
		</div>
	);
}

export default App;
